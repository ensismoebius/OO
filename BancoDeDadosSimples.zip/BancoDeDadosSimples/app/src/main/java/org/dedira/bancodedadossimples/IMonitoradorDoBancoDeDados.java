package org.dedira.bancodedadossimples;

public interface IMonitoradorDoBancoDeDados<TipoDoObjeto> {
    void operacaoRealizada(boolean realizada, TipoDoObjeto objetoPraSalvar);
}
