package org.dedira.bancodedadossimples;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BancoDeDados bd = new BancoDeDados();

        // 1. Exemplo de carregar todos os documentos
        ArrayList<Documento> documentos = new ArrayList<>();
        bd.carregaTodosOsDocumentos(documentos, (sucesso, doc) -> {
            if (sucesso) {
                for (Documento documento : documentos) {
                    System.out.println("Documento ID: " + documento.getId());
                    System.out.println("Nome: " + documento.getNome());
                    System.out.println("Idade: " + documento.getIdade());
                }
            } else {
                System.out.println("Falha ao carregar os documentos.");
            }
        });

        // 2. Exemplo de carregar um único documento
        bd.carregaDocumento("documentoID", (sucesso, documento) -> {
            if (sucesso && documento != null) {
                System.out.println("Documento carregado com sucesso:");
                System.out.println("Documento ID: " + documento.getId());
                System.out.println("Nome: " + documento.getNome());
                System.out.println("Idade: " + documento.getIdade());
            } else {
                System.out.println("Falha ao carregar o documento.");
            }
        });

        // 3. Exemplo de salvar um novo documento
        Documento novoDocumento = new Documento();
        novoDocumento.setNome("João da Silva");
        novoDocumento.setIdade(30);
        bd.salvaDocumento(novoDocumento, (sucesso, documentoSalvo) -> {
            if (sucesso) {
                System.out.println("Documento salvo com sucesso.");
            } else {
                System.out.println("Falha ao salvar o documento.");
            }
        });

        // 4. Exemplo de atualizar um documento existente
        Map<String, Object> camposParaAtualizar = new HashMap<>();
        camposParaAtualizar.put("nome", "Maria de Souza");
        camposParaAtualizar.put("idade", 25);
        bd.atualizaDocumento("documentoID", camposParaAtualizar, (sucesso, documentoAtualizado) -> {
            if (sucesso) {
                System.out.println("Documento atualizado com sucesso.");
            } else {
                System.out.println("Falha ao atualizar o documento.");
            }
        });

        // 5. Exemplo de apagar um documento
        bd.apagarDocumento("documentoID", (sucesso, doc) -> {
            if (sucesso) {
                System.out.println("Documento apagado com sucesso.");
            } else {
                System.out.println("Falha ao apagar o documento.");
            }
        });
    }
}
