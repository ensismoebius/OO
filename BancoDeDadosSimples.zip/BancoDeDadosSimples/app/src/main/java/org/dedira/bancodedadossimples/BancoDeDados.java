package org.dedira.bancodedadossimples;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BancoDeDados {
    private final FirebaseFirestore firebase;

    public BancoDeDados() {
        // Inicializa o Firebase
        firebase = FirebaseFirestore.getInstance();
        FirebaseFirestoreSettings.Builder carregadorDeConfiguracao = new FirebaseFirestoreSettings.Builder(firebase.getFirestoreSettings());
        FirebaseFirestoreSettings settings = carregadorDeConfiguracao.build();
        firebase.setFirestoreSettings(settings);
    }

    /**
     * Método auxiliar para lidar com o resultado de operações
     */
    private void processarResposta(boolean sucesso, Documento documento, IMonitoradorDoBancoDeDados<Documento> monitor) {
        monitor.operacaoRealizada(sucesso, documento);
    }

    /**
     * Apaga um documento dada uma identificação de documento
     *
     * @param idDoDocumento
     * @param escutador
     */
    public void apagarDocumento(String idDoDocumento, IMonitoradorDoBancoDeDados<Documento> escutador) {
        firebase
                .collection("Documentos")
                .document(idDoDocumento)
                .delete()
                .addOnSuccessListener(
                        v -> processarResposta(
                                true,
                                null,
                                escutador)
                ).addOnFailureListener(
                        v -> processarResposta(
                                false,
                                null,
                                escutador)
                );
    }

    /**
     * Atualiza os campos de um documento dada uma identificação de documento
     *
     * @param idDoDocumento
     * @param listaDeCamposParaAtualizar
     * @param escutador
     */
    public void atualizaDocumento(String idDoDocumento, Map<String, Object> listaDeCamposParaAtualizar, IMonitoradorDoBancoDeDados<Documento> escutador) {
        firebase
                .collection("Documentos")
                .document(idDoDocumento)
                .update(listaDeCamposParaAtualizar)
                .addOnSuccessListener(
                        v -> processarResposta(
                                true,
                                null,
                                escutador)
                ).addOnFailureListener(
                        v -> processarResposta(
                                false,
                                null,
                                escutador)
                );
    }

    /**
     * Carrega todos os documentos de uma coleção
     *
     * @param listaDeDocumentos
     * @param escutador
     */
    public void carregaTodosOsDocumentos(ArrayList<Documento> listaDeDocumentos, IMonitoradorDoBancoDeDados<Documento> escutador) {
        firebase.collection("Documentos")
                .get()
                .addOnCompleteListener(solicitacao -> {
                    // Verifica se a solicitação foi bem sucedida
                    if (solicitacao.isSuccessful()) {
                        // Recupera os documentos carregados
                        for (QueryDocumentSnapshot objeto : solicitacao.getResult()) {
                            // Converte o objeto para um Documento
                            Documento d = objeto.toObject(Documento.class);
                            d.setId(objeto.getId());
                            // Adiciona o Documento à lista
                            listaDeDocumentos.add(d);
                        }
                        // Informa que a operação foi bem sucedida
                        processarResposta(true, null, escutador);
                    } else {
                        // Informa que a operação falhou
                        processarResposta(false, null, escutador);
                    }
                });
    }

    /**
     * Salva ou atualiza um documento
     *
     * @param documento
     * @param escutador
     */
    public void salvaDocumento(Documento documento, IMonitoradorDoBancoDeDados<Documento> escutador) {

        // Verifica se é um novo documento ou um documento existente
        if (documento.getId() == null) {
            // Novo documento
            firebase
                    .collection("Documentos")
                    .add(documento)
                    .addOnSuccessListener(
                            refDoc -> processarResposta(true, documento, escutador)
                    ).addOnFailureListener(
                            refDoc -> processarResposta(false, null, escutador)
                    );
        } else {
            // Documento existente
            // Cria um mapa com os campos a serem atualizados
            Map<String, Object> campos = new HashMap<>();
            campos.put("nome", documento.getNome());
            campos.put("idade", documento.getIdade());

            // Atualiza o documento
            atualizaDocumento(documento.getId(), campos, escutador);
        }
    }

    /**
     * Carrega um documento dado uma identificação de documento
     *
     * @param idDoDocumento
     * @param escutador
     */
    public void carregaDocumento(String idDoDocumento, IMonitoradorDoBancoDeDados<Documento> escutador) {
        // Cria uma referência ao documento
        DocumentReference referenciaAoDocumento;
        try {
            // Carrega um documento dado uma identificação de documento
            referenciaAoDocumento = firebase.collection("Documentos").document(idDoDocumento);
        } catch (Exception e) {
            processarResposta(false, null, escutador);
            return;
        }

        // Carrega o documento
        referenciaAoDocumento
                .get()
                .addOnCompleteListener(
                        solicitacao -> {
                            // Converte o objeto recuperado para um Documento
                            Documento d = solicitacao.getResult().toObject(Documento.class);

                            // Verifica se a solicitação foi bem sucedida e se o documento existe no banco de dados
                            if (!solicitacao.isSuccessful() || d == null) {
                                // Informa que a operação falhou
                                processarResposta(false, null, escutador);
                                return;
                            }

                            // Se o documento existir, define o ID do documento
                            if (d != null) {
                                d.setId(referenciaAoDocumento.getId());
                                // Informa que a operação foi bem sucedida
                                processarResposta(true, d, escutador);
                            } else {
                                // Informa que a operação falhou
                                processarResposta(true, null, escutador);
                            }
                        })
                .addOnFailureListener(
                        // Informa que a operação falhou
                        tarefa -> processarResposta(false, null, escutador)
                );
    }
}
